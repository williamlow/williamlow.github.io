
var reportFreq = "biweekly"
var geography = "Northeast Nigeria (Adamawa, Borno and Yobe states)"
var conflict_period = "02 Oct 23 - 14 Oct 23"
var report_period = "02 Oct 23 - 31 Dec 23"
